
package com.govbudget.management.ministrybudget.service;

import com.govbudget.management.ministrybudget.dto.CumulativeExpenditureRequest;
import com.govbudget.management.ministrybudget.entity.*;
import com.govbudget.management.ministrybudget.repository.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.govbudget.management.operational.expensehead.entity.ExpenseHead;
import com.govbudget.management.operational.expensehead.repository.ExpenseHeadRepository;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProjectExpenditureService {

    private final ProjectRepository projectRepository;
    private final ProjectExpenditureHistoryRepository historyRepository;
private final ExpenseHeadRepository expenseHeadRepository; 

    public ProjectExpenditureService(
            ProjectRepository projectRepository,
            ProjectExpenditureHistoryRepository historyRepository,
ExpenseHeadRepository expenseHeadRepository) {
        this.projectRepository = projectRepository;
        this.historyRepository = historyRepository;
this.expenseHeadRepository = expenseHeadRepository; 
    }

    @Transactional
    public ProjectExpenditureHistory create(
            Long projectId, CumulativeExpenditureRequest request) {

        Project project = projectRepository.findById(projectId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Project not found"));

        validateRequest(request);
        validateExpenseHead(request.expenseHeadId());

        List<ProjectExpenditureHistory> history =
                historyRepository.findByProjectIdOrderByReportDateDesc(projectId);

        if (!history.isEmpty()) {
            ProjectExpenditureHistory latest = history.get(0);

            if (!request.reportDate().isAfter(latest.getReportDate())) {
                throw new IllegalArgumentException(
                        "Report date must be later than the latest report date");
            }

            if (request.cumulativeAmount()
                    .compareTo(latest.getCumulativeAmount()) < 0) {
                throw new IllegalArgumentException(
                        "Cumulative amount cannot be less than previous report");
            }
        }

        if (request.cumulativeAmount()
                .compareTo(project.getAllocatedAmount()) > 0) {
            throw new IllegalArgumentException(
                    "Expenditure cannot exceed project allocation");
        }

        BigDecimal previousAmount = history.isEmpty()
                ? BigDecimal.ZERO
                : history.get(0).getCumulativeAmount();

        ProjectExpenditureHistory record =
                new ProjectExpenditureHistory();

        record.setProjectId(projectId);
        record.setReportDate(request.reportDate());
        record.setCumulativeAmount(request.cumulativeAmount());
        record.setIncrementalAmount(
                request.cumulativeAmount().subtract(previousAmount));
        record.setRemarks(request.remarks());
        record.setExpenseHeadId(request.expenseHeadId());

        return historyRepository.save(record);
    }

    @Transactional(readOnly = true)
    public List<ProjectExpenditureHistory> getHistory(Long projectId) {

        if (!projectRepository.existsById(projectId)) {
            throw new IllegalArgumentException("Project not found");
        }

        return historyRepository
                .findByProjectIdOrderByReportDateDesc(projectId);
    }
    private void validateExpenseHead(Long expenseHeadId) {
        if (expenseHeadId == null) {
            throw new IllegalArgumentException("Budget head is required");
        }

        ExpenseHead head = expenseHeadRepository.findById(expenseHeadId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Budget head not found"));

        if (!Boolean.TRUE.equals(head.getActive())) {
            throw new IllegalArgumentException("Budget head is not active");
        }
    }

    private void validateRequest(CumulativeExpenditureRequest request) {
        if (request.reportDate() == null) {
            throw new IllegalArgumentException("Report date is required");
        }

        if (request.cumulativeAmount() == null
                || request.cumulativeAmount()
                .compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Invalid cumulative amount");
        }
    }
}
