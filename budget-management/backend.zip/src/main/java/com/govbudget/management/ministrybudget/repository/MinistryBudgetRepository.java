
package com.govbudget.management.ministrybudget.repository;

import com.govbudget.management.ministrybudget.entity.MinistryBudget;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.UUID;

public interface MinistryBudgetRepository
        extends JpaRepository<MinistryBudget, Long> {

    Optional<MinistryBudget> findByFiscalYearIdAndOrganizationId(
            Long fiscalYearId, UUID organizationId);
}
