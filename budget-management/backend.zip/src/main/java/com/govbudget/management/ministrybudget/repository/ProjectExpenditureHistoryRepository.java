
package com.govbudget.management.ministrybudget.repository;

import com.govbudget.management.ministrybudget.entity.ProjectExpenditureHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ProjectExpenditureHistoryRepository
        extends JpaRepository<ProjectExpenditureHistory, Long> {

    List<ProjectExpenditureHistory>
    findByProjectIdOrderByReportDateDesc(Long projectId);

    Optional<ProjectExpenditureHistory>
    findFirstByProjectIdAndReportDateLessThanOrderByReportDateDesc(
            Long projectId, LocalDate reportDate);

    Optional<ProjectExpenditureHistory>
    findFirstByProjectIdAndReportDateLessThanEqualOrderByReportDateDesc(
            Long projectId, LocalDate reportDate);

    boolean existsByProjectIdAndReportDate(
            Long projectId, LocalDate reportDate);

}
