
package com.govbudget.management.ministrybudget.service;

import com.govbudget.management.ministrybudget.dto.CumulativeExpenditureRequest;
import com.govbudget.management.ministrybudget.entity.*;
import com.govbudget.management.ministrybudget.repository.*;
import com.govbudget.management.operational.expensehead.entity.ExpenseHead;
import com.govbudget.management.operational.expensehead.repository.ExpenseHeadRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OfficeExpenditureService {

    private final OfficeBudgetAllocationRepository allocationRepository;
    private final OfficeExpenditureHistoryRepository historyRepository;
    private final CategoryBudgetSourceRepository sourceRepository;
    private final MinistryBudgetCategoryRepository categoryRepository;
private final ExpenseHeadRepository expenseHeadRepository;
    public OfficeExpenditureService(
            OfficeBudgetAllocationRepository allocationRepository,
            OfficeExpenditureHistoryRepository historyRepository,
            CategoryBudgetSourceRepository sourceRepository,
            MinistryBudgetCategoryRepository categoryRepository,
ExpenseHeadRepository expenseHeadRepository) {
        this.allocationRepository = allocationRepository;
        this.historyRepository = historyRepository;
        this.sourceRepository = sourceRepository;
        this.categoryRepository = categoryRepository;
this.expenseHeadRepository = expenseHeadRepository; 
    }

    @Transactional
    public OfficeExpenditureHistory create(
            Long allocationId, CumulativeExpenditureRequest request) {

        OfficeBudgetAllocation allocation = allocationRepository
                .findById(allocationId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Office allocation not found"));

        CategoryBudgetSource source = sourceRepository
                .findById(allocation.getCategorySourceId())
                .orElseThrow();

        MinistryBudgetCategory category = categoryRepository
                .findById(source.getCategoryId())
                .orElseThrow();

        boolean operational = "OPERATIONAL".equals(category.getCategoryCode());
        boolean developmentBlock =
                "DEVELOPMENT".equals(category.getCategoryCode())
                && "BLOCK".equals(source.getSourceCode());

        if (!operational && !developmentBlock) {
            throw new IllegalArgumentException(
                    "Direct office expenditure is allowed only for Operational or Development Block");
        }

        if (request.reportDate() == null
                || request.cumulativeAmount() == null
                || request.cumulativeAmount()
                .compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Invalid expenditure report");
        }
        validateExpenseHead(request.expenseHeadId());

        List<OfficeExpenditureHistory> history =
                historyRepository
                        .findByOfficeBudgetAllocationIdOrderByReportDateDesc(
                                allocationId);

        BigDecimal previousAmount = BigDecimal.ZERO;

        if (!history.isEmpty()) {
            OfficeExpenditureHistory latest = history.get(0);

            if (!request.reportDate().isAfter(latest.getReportDate())) {
                throw new IllegalArgumentException(
                        "Report date must be later than latest report date");
            }

            if (request.cumulativeAmount()
                    .compareTo(latest.getCumulativeAmount()) < 0) {
                throw new IllegalArgumentException(
                        "Cumulative amount cannot decrease");
            }

            previousAmount = latest.getCumulativeAmount();
        }

        if (request.cumulativeAmount()
                .compareTo(allocation.getAllocatedAmount()) > 0) {
            throw new IllegalArgumentException(
                    "Expenditure exceeds office allocation");
        }

        OfficeExpenditureHistory record = new OfficeExpenditureHistory();

        record.setOfficeBudgetAllocationId(allocationId);
        record.setReportDate(request.reportDate());
        record.setCumulativeAmount(request.cumulativeAmount());
        record.setIncrementalAmount(
                request.cumulativeAmount().subtract(previousAmount));
        record.setRemarks(request.remarks());
        record.setExpenseHeadId(request.expenseHeadId());

        return historyRepository.save(record);
    }

    @Transactional(readOnly = true)
    public List<OfficeExpenditureHistory> getHistory(Long allocationId) {

        if (!allocationRepository.existsById(allocationId)) {
            throw new IllegalArgumentException("Office allocation not found");
        }

        return historyRepository
                .findByOfficeBudgetAllocationIdOrderByReportDateDesc(
                        allocationId);
    }
    private void validateExpenseHead(Long expenseHeadId) {
        if (expenseHeadId == null) {
            throw new IllegalArgumentException("Budget head is required");
        }

        ExpenseHead head = expenseHeadRepository.findById(expenseHeadId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Budget head not found"));

        if (!Boolean.TRUE.equals(head.getActive())) {
            throw new IllegalArgumentException("Budget head is not active");
        }
    }
}
