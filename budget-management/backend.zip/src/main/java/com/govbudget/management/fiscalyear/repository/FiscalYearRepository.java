package com.govbudget.management.fiscalyear.repository;

import com.govbudget.management.fiscalyear.entity.FiscalYear;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FiscalYearRepository
        extends JpaRepository<FiscalYear, Long> {

    boolean existsByName(String name);

    boolean existsByNameAndIdNot(String name, Long id);

    Optional<FiscalYear> findByIsActiveTrue();
}