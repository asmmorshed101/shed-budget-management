
package com.govbudget.management.ministrybudget.repository;

import com.govbudget.management.ministrybudget.entity.OfficeExpenditureHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface OfficeExpenditureHistoryRepository
        extends JpaRepository<OfficeExpenditureHistory, Long> {

    List<OfficeExpenditureHistory>
    findByOfficeBudgetAllocationIdOrderByReportDateDesc(
            Long officeBudgetAllocationId);

    Optional<OfficeExpenditureHistory>
    findFirstByOfficeBudgetAllocationIdAndReportDateLessThanEqualOrderByReportDateDesc(
            Long officeBudgetAllocationId, LocalDate reportDate);

    boolean existsByOfficeBudgetAllocationIdAndReportDate(
            Long officeBudgetAllocationId, LocalDate reportDate);
}
