
import { BrowserRouter, Routes, Route } from "react-router-dom";

import MainLayout from "./layouts/MainLayout";
import Dashboard from "./pages/Dashboard";
import PlaceholderPage from "./pages/PlaceholderPage";
import MinistryBudget from "./pages/MinistryBudget";
import BudgetSources from "./pages/BudgetSources";
import OfficeAllocation from "./pages/OfficeAllocation";
import Projects from "./pages/Projects";
import OfficeManagement from "./pages/OfficeManagement";
import FiscalYears from "./pages/FiscalYears";
import ExpenditureEntry from "./pages/ExpenditureEntry";
import ProjectDashboard from "./pages/ProjectDashboard";
import CentralReports from "./pages/CentralReports";
import DownloadReports from "./pages/DownloadReports";
import ExpenseHeads from "./pages/ExpenseHeads";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<Dashboard />} />

          <Route
  path="/ministry-budget"
  element={<MinistryBudget />}
/>
          

          <Route
            path="/categories"
            element={<PlaceholderPage title="Budget Categories" />}
          />
<Route path="/reports" element={<CentralReports />} />
          <Route
  path="/sources"
  element={<BudgetSources />}
/>
<Route
  path="/expense-heads"
  element={<ExpenseHeads />}
/>
          <Route
  path="/offices"
  element={<OfficeManagement />}
/>

          <Route
  path="/office-allocations"
  element={<OfficeAllocation />}
/>
<Route
  path="/project-dashboard"
  element={<ProjectDashboard />}
/>
   <Route
  path="/projects"
  element={<Projects />}
/>
<Route
  path="/download-reports"
  element={<DownloadReports />}
/>

          <Route path="/expenditures" element={<ExpenditureEntry />} />

          <Route
            path="/reports"
            element={<PlaceholderPage title="Central Reports" />}
          />

          <Route
            path="/fiscal-years"
            element={<FiscalYears />}
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
