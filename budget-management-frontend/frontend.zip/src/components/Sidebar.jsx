
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Wallet,
  Layers,
  Building2,
  FolderKanban,
  Receipt,
  FileBarChart,
  CalendarDays,
  ChevronLeft,
  ReceiptText ,
  GraduationCap,
  ChartNoAxesCombined,
  FileDown,
  Tags,
} from "lucide-react";

const menuItems = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Ministry Budget", path: "/ministry-budget", icon: Wallet },
  { label: "Budget Categories", path: "/categories", icon: Layers },
  { label: "Expenditure Heads", path: "/expense-heads", icon: Tags },
  { label: "Budget Sources", path: "/sources", icon: Wallet },
  { label: "Office Management", path: "/offices", icon: Building2 },
  { label: "Office Allocation", path: "/office-allocations", icon: Building2 },
  { label: "Project Management", path: "/projects", icon: FolderKanban },
  // { label: "Expenditure Entry", path: "/expenditures", icon: Receipt },
  { label: "Central Reports", path: "/reports", icon: FileBarChart },
  { label: "Fiscal Years", path: "/fiscal-years", icon: CalendarDays },
  { label: "Expenditure Entry", path: "/expenditures", icon: ReceiptText },
  { label: "Project Dashboard", path: "/project-dashboard", icon: ChartNoAxesCombined },
  { label: "Download Reports", path: "/download-reports", icon: FileDown },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-icon">
          <GraduationCap size={25} />
        </div>
        <div>
          <h2>SHED Budget</h2>
          <span>Management System</span>
        </div>
      </div>

      <div className="sidebar-label">MAIN MENU</div>

      <nav className="sidebar-nav">
        {menuItems.map(({ label, path, icon: Icon }) => (
          <NavLink
            key={path}
            to={path}
            end={path === "/"}
            className={({ isActive }) =>
              `nav-link ${isActive ? "active" : ""}`
            }
          >
            <Icon size={19} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <span>Secondary and Higher</span>
        <span>Education Division</span>
        <small>Budget Management System</small>
      </div>
    </aside>
  );
}
