
import { Bell, Menu } from "lucide-react";

export default function Header({ onMenuClick }) {
  return (
    <header className="top-header">
      <button className="mobile-menu" onClick={onMenuClick}>
        <Menu size={22} />
      </button>

      <div>
        <h3>Secondary and Higher Education Division</h3>
        <p>Government of the People's Republic of Bangladesh</p>
      </div>

      <div className="header-actions">
        <button className="icon-button" aria-label="Notifications">
          <Bell size={20} />
        </button>
        <div className="user-avatar">A</div>
      </div>
    </header>
  );
}
