
import { useEffect, useMemo, useState } from "react";
import api from "../api/axios";

const fiscalYearId = import.meta.env.VITE_FISCAL_YEAR_ID;
const organizationId = import.meta.env.VITE_SHED_ORGANIZATION_ID;

const money = (value) =>
  new Intl.NumberFormat("en-BD", {
    style: "currency",
    currency: "BDT",
    maximumFractionDigits: 2,
  }).format(Number(value || 0));

const getArray = (data) => {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.content)) return data.content;
  if (Array.isArray(data?.data)) return data.data;
  return [];
};

const getError = (error) =>
  error.response?.data?.message ||
  error.response?.data?.error ||
  error.message ||
  "Something went wrong.";

export default function ExpenditureEntry() {
  const [activeTab, setActiveTab] = useState("PROJECT");

  const [projectAllocations, setProjectAllocations] = useState([]);
  const [officeAllocations, setOfficeAllocations] = useState([]);

  const [selectedProjectAllocation, setSelectedProjectAllocation] =
    useState("");
  const [selectedOfficeAllocation, setSelectedOfficeAllocation] =
    useState("");

  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState("");

  const [history, setHistory] = useState([]);

  const [expenseHeads, setExpenseHeads] = useState([]);
  const [selectedHead, setSelectedHead] = useState("");

  const [reportDate, setReportDate] = useState(
    new Date().toISOString().slice(0, 10)
  );
  const [cumulativeAmount, setCumulativeAmount] = useState("");
  const [remarks, setRemarks] = useState("");

  const [loading, setLoading] = useState(true);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Load budget, categories, sources and office allocations
  useEffect(() => {
    const loadAllocations = async () => {
      try {
        setLoading(true);
        setError("");

        const [budgetResponse, organizationResponse] = await Promise.all([
          api.get("/ministry-budgets/by-fiscal-year", {
            params: { fiscalYearId, organizationId },
          }),
          api.get("/organizations/hierarchy"),
        ]);

        const budgetData = budgetResponse.data;
        const budget = Array.isArray(budgetData)
          ? budgetData[0]
          : budgetData;

        if (!budget?.id) {
          throw new Error("No ministry budget found for this fiscal year.");
        }

        const organizations = getArray(organizationResponse.data);
        const organizationMap = new Map();

        const flattenOrganizations = (items) => {
          items.forEach((item) => {
            organizationMap.set(String(item.id), item);
            if (Array.isArray(item.children)) {
              flattenOrganizations(item.children);
            }
          });
        };

        flattenOrganizations(organizations);

        const categoryResponse = await api.get(
          `/ministry-budgets/${budget.id}/categories`
        );
        const categories = getArray(categoryResponse.data);

        const projectCategory = categories.find(
          (item) => item.categoryCode === "DEVELOPMENT"
        );

        const projectSources = projectCategory
          ? getArray(
              (
                await api.get(
                  `/budget-categories/${projectCategory.id}/sources`
                )
              ).data
            )
          : [];

        const adpSource = projectSources.find(
          (item) => item.sourceCode === "ADP"
        );

        if (adpSource) {
          const response = await api.get(
            `/budget-sources/${adpSource.id}/offices`
          );
          const allocations = getArray(response.data);

          setProjectAllocations(
            allocations.map((allocation) => ({
              ...allocation,
              officeName:
                organizationMap.get(String(allocation.organizationId))
                  ?.nameBn ||
                organizationMap.get(String(allocation.organizationId))
                  ?.name ||
                `Office ${allocation.organizationId}`,
            }))
          );
        }

        // Office expenditure: Operational and Development BLOCK allocations
        const officeResults = [];

        for (const category of categories) {
          if (
            category.categoryCode !== "OPERATIONAL" &&
            category.categoryCode !== "DEVELOPMENT"
          ) {
            continue;
          }

          const sourceResponse = await api.get(
            `/budget-categories/${category.id}/sources`
          );
          const sources = getArray(sourceResponse.data);

          for (const source of sources) {
            // Development ADP is handled through project expenditure.
            if (
              category.categoryCode === "DEVELOPMENT" &&
              source.sourceCode === "ADP"
            ) {
              continue;
            }

            const officeResponse = await api.get(
              `/budget-sources/${source.id}/offices`
            );

            getArray(officeResponse.data).forEach((allocation) => {
              const office =
                organizationMap.get(String(allocation.organizationId));

              officeResults.push({
                ...allocation,
                categoryName: category.categoryName,
                sourceName: source.sourceName,
                officeName:
                  office?.nameBn ||
                  office?.name ||
                  `Office ${allocation.organizationId}`,
              });
            });
          }
        }

        setOfficeAllocations(officeResults);

        if (adpSource) {
          const response = await api.get(
            `/budget-sources/${adpSource.id}/offices`
          );
          const allocations = getArray(response.data);
          if (allocations.length > 0) {
            setSelectedProjectAllocation(String(allocations[0].id));
          }
        }

        if (officeResults.length > 0) {
          setSelectedOfficeAllocation(String(officeResults[0].id));
        }
      } catch (err) {
        setError(getError(err));
      } finally {
        setLoading(false);
      }
    };

    loadAllocations();
  }, []);

  // Load expense (budget) heads
  useEffect(() => {
    const loadHeads = async () => {
      try {
        const response = await api.get("/expense-heads");
        setExpenseHeads(getArray(response.data));
      } catch (err) {
        setError(getError(err));
      }
    };

    loadHeads();
  }, []);

  // Only active heads can be chosen for a new entry
  const activeHeads = useMemo(
    () => expenseHeads.filter((head) => head.active === true),
    [expenseHeads]
  );

  // History may contain heads that were deactivated later, so look up in all heads
  const headLabel = (head) => `${head.code} - ${head.nameBn || head.name}`;

  const headNameById = useMemo(() => {
    const map = new Map();
    expenseHeads.forEach((head) => map.set(String(head.id), headLabel(head)));
    return map;
  }, [expenseHeads]);

  const selectedProjectAllocationData = useMemo(
    () =>
      projectAllocations.find(
        (item) => String(item.id) === selectedProjectAllocation
      ),
    [projectAllocations, selectedProjectAllocation]
  );

  const selectedOfficeAllocationData = useMemo(
    () =>
      officeAllocations.find(
        (item) => String(item.id) === selectedOfficeAllocation
      ),
    [officeAllocations, selectedOfficeAllocation]
  );

  // Load projects when a Development ADP allocation is selected
  useEffect(() => {
    const loadProjects = async () => {
      if (!selectedProjectAllocation) {
        setProjects([]);
        setSelectedProject("");
        return;
      }

      try {
        const response = await api.get(
          `/office-allocations/${selectedProjectAllocation}/projects`
        );

        const items = getArray(response.data);
        setProjects(items);
        setSelectedProject(items.length ? String(items[0].id) : "");
      } catch (err) {
        setProjects([]);
        setSelectedProject("");
        setError(getError(err));
      }
    };

    loadProjects();
  }, [selectedProjectAllocation]);

  const selectedProjectData = useMemo(
    () => projects.find((item) => String(item.id) === selectedProject),
    [projects, selectedProject]
  );

  // Load expenditure history
  useEffect(() => {
    const loadHistory = async () => {
      const id =
        activeTab === "PROJECT" ? selectedProject : selectedOfficeAllocation;

      if (!id) {
        setHistory([]);
        return;
      }

      try {
        setHistoryLoading(true);
        setError("");

        const endpoint =
          activeTab === "PROJECT"
            ? `/projects/${id}/expenditures`
            : `/office-allocations/${id}/expenditures`;

        const response = await api.get(endpoint);
        setHistory(getArray(response.data));
      } catch (err) {
        setHistory([]);
        setError(getError(err));
      } finally {
        setHistoryLoading(false);
      }
    };

    loadHistory();
  }, [activeTab, selectedProject, selectedOfficeAllocation]);

  const currentHistory = history;
  const latestRecord = currentHistory[0];

  const previousCumulative = Number(
    latestRecord?.cumulativeAmount || 0
  );

  const allocatedAmount = Number(
    activeTab === "PROJECT"
      ? selectedProjectData?.allocatedAmount || 0
      : selectedOfficeAllocationData?.allocatedAmount || 0
  );

  const enteredAmount = Number(cumulativeAmount || 0);
  const incrementalAmount = enteredAmount - previousCumulative;

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");

    const targetId =
      activeTab === "PROJECT" ? selectedProject : selectedOfficeAllocation;

    if (!targetId) {
      setError(
        activeTab === "PROJECT"
          ? "Please select a project."
          : "Please select an office allocation."
      );
      return;
    }

    if (!selectedHead) {
      setError("Please select a budget head.");
      return;
    }

    if (!reportDate || cumulativeAmount === "") {
      setError("Please enter report date and cumulative expenditure.");
      return;
    }

    if (enteredAmount < previousCumulative) {
      setError(
        `Cumulative expenditure cannot be less than the previous amount (${money(previousCumulative)}).`
      );
      return;
    }

    if (enteredAmount > allocatedAmount) {
      setError(
        `Cumulative expenditure cannot exceed the allocation (${money(allocatedAmount)}).`
      );
      return;
    }

    try {
      setSaving(true);

      const endpoint =
        activeTab === "PROJECT"
          ? `/projects/${targetId}/expenditures`
          : `/office-allocations/${targetId}/expenditures`;

      await api.post(endpoint, {
        reportDate,
        cumulativeAmount: enteredAmount,
        remarks,
        expenseHeadId: Number(selectedHead),
      });

      setSuccess("Expenditure report submitted successfully.");
      setCumulativeAmount("");
      setRemarks("");
      setSelectedHead("");

      const response = await api.get(endpoint);
      setHistory(getArray(response.data));
    } catch (err) {
      setError(getError(err));
    } finally {
      setSaving(false);
    }
  };

  const changeTab = (tab) => {
    setActiveTab(tab);
    setError("");
    setSuccess("");
    setCumulativeAmount("");
    setRemarks("");
    setSelectedHead("");
  };

  const styles = {
    page: { padding: "24px", maxWidth: "1200px", margin: "0 auto" },
    heading: { fontSize: "25px", fontWeight: 700, marginBottom: "6px" },
    subtitle: { color: "#64748b", marginBottom: "24px" },
    tabs: { display: "flex", gap: "10px", marginBottom: "22px" },
    tab: (active) => ({
      padding: "11px 20px",
      borderRadius: "8px",
      border: "1px solid #dbe2ea",
      background: active ? "#1d4ed8" : "#fff",
      color: active ? "#fff" : "#334155",
      cursor: "pointer",
      fontWeight: 600,
    }),
    card: {
      background: "#fff",
      border: "1px solid #e2e8f0",
      borderRadius: "12px",
      padding: "22px",
      marginBottom: "20px",
    },
    label: {
      display: "block",
      fontWeight: 600,
      fontSize: "14px",
      marginBottom: "7px",
      color: "#334155",
    },
    input: {
      width: "100%",
      padding: "11px 12px",
      border: "1px solid #cbd5e1",
      borderRadius: "7px",
      fontSize: "14px",
      boxSizing: "border-box",
      background: "#fff",
    },
    grid: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
      gap: "18px",
    },
    stat: {
      background: "#f8fafc",
      padding: "16px",
      borderRadius: "9px",
      border: "1px solid #e2e8f0",
    },
    statLabel: { fontSize: "13px", color: "#64748b", marginBottom: "7px" },
    statValue: { fontSize: "19px", fontWeight: 700, color: "#0f172a" },
    button: {
      background: "#1d4ed8",
      color: "#fff",
      padding: "12px 22px",
      border: 0,
      borderRadius: "7px",
      fontWeight: 600,
      cursor: "pointer",
    },
    tableWrap: { overflowX: "auto" },
    table: { width: "100%", borderCollapse: "collapse", minWidth: "650px" },
    th: {
      textAlign: "left",
      padding: "12px",
      background: "#f8fafc",
      color: "#475569",
      fontSize: "13px",
      borderBottom: "1px solid #e2e8f0",
    },
    td: {
      padding: "12px",
      borderBottom: "1px solid #e2e8f0",
      fontSize: "14px",
    },
  };

  if (loading) {
    return <div style={styles.page}>Loading expenditure information...</div>;
  }

  return (
    <div style={styles.page}>
      <h1 style={styles.heading}>Expenditure Entry</h1>
      <p style={styles.subtitle}>
        Submit and review cumulative expenditure reports.
      </p>

      <div style={styles.tabs}>
        <button
          type="button"
          style={styles.tab(activeTab === "PROJECT")}
          onClick={() => changeTab("PROJECT")}
        >
          Project Expenditure
        </button>

        <button
          type="button"
          style={styles.tab(activeTab === "OFFICE")}
          onClick={() => changeTab("OFFICE")}
        >
          Office Expenditure
        </button>
      </div>

      {error && (
        <div
          style={{
            ...styles.card,
            color: "#b91c1c",
            background: "#fef2f2",
            borderColor: "#fecaca",
          }}
        >
          {error}
        </div>
      )}

      {success && (
        <div
          style={{
            ...styles.card,
            color: "#166534",
            background: "#f0fdf4",
            borderColor: "#bbf7d0",
          }}
        >
          {success}
        </div>
      )}

      <div style={styles.card}>
        <h2 style={{ fontSize: "18px", marginTop: 0, marginBottom: "20px" }}>
          {activeTab === "PROJECT"
            ? "Project Expenditure Information"
            : "Office Expenditure Information"}
        </h2>

        <div style={styles.grid}>
          {activeTab === "PROJECT" ? (
            <>
              <div>
                <label style={styles.label}>Development ADP Office</label>
                <select
                  style={styles.input}
                  value={selectedProjectAllocation}
                  onChange={(e) =>
                    setSelectedProjectAllocation(e.target.value)
                  }
                >
                  <option value="">Select office allocation</option>
                  {projectAllocations.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.officeName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={styles.label}>Project</label>
                <select
                  style={styles.input}
                  value={selectedProject}
                  onChange={(e) => setSelectedProject(e.target.value)}
                  disabled={!projects.length}
                >
                  <option value="">Select project</option>
                  {projects.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.projectCode} - {item.projectName}
                    </option>
                  ))}
                </select>
              </div>
            </>
          ) : (
            <div>
              <label style={styles.label}>Office Allocation</label>
              <select
                style={styles.input}
                value={selectedOfficeAllocation}
                onChange={(e) => setSelectedOfficeAllocation(e.target.value)}
              >
                <option value="">Select office allocation</option>
                {officeAllocations.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.officeName} — {item.categoryName} / {item.sourceName}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      <div style={styles.grid}>
        <div style={styles.stat}>
          <div style={styles.statLabel}>Allocated Budget</div>
          <div style={styles.statValue}>{money(allocatedAmount)}</div>
        </div>

        <div style={styles.stat}>
          <div style={styles.statLabel}>Previous Cumulative Expenditure</div>
          <div style={styles.statValue}>{money(previousCumulative)}</div>
        </div>

        <div style={styles.stat}>
          <div style={styles.statLabel}>Remaining Budget</div>
          <div style={styles.statValue}>
            {money(Math.max(allocatedAmount - previousCumulative, 0))}
          </div>
        </div>
      </div>

      <div style={{ ...styles.card, marginTop: "20px" }}>
        <h2 style={{ fontSize: "18px", marginTop: 0, marginBottom: "20px" }}>
          Submit Expenditure Report
        </h2>

        <form onSubmit={handleSubmit}>
          <div style={styles.grid}>
            <div>
              <label style={styles.label}>Budget Head</label>
              <select
                style={styles.input}
                value={selectedHead}
                onChange={(e) => setSelectedHead(e.target.value)}
                required
              >
                <option value="">Select budget head</option>
                {activeHeads.map((head) => (
                  <option key={head.id} value={head.id}>
                    {headLabel(head)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={styles.label}>Report Date</label>
              <input
                type="date"
                style={styles.input}
                value={reportDate}
                onChange={(e) => setReportDate(e.target.value)}
                required
              />
            </div>

            <div>
              <label style={styles.label}>Cumulative Expenditure (৳)</label>
              <input
                type="number"
                min={previousCumulative}
                max={allocatedAmount}
                step="0.01"
                style={styles.input}
                value={cumulativeAmount}
                onChange={(e) => setCumulativeAmount(e.target.value)}
                placeholder="Enter total expenditure to date"
                required
              />
            </div>

            <div>
              <label style={styles.label}>New Expenditure Since Previous Report</label>
              <input
                type="text"
                style={{ ...styles.input, background: "#f8fafc" }}
                value={
                  cumulativeAmount === ""
                    ? "—"
                    : money(Math.max(incrementalAmount, 0))
                }
                readOnly
              />
            </div>
          </div>

          <div style={{ marginTop: "18px" }}>
            <label style={styles.label}>Remarks</label>
            <textarea
              style={{ ...styles.input, minHeight: "85px", resize: "vertical" }}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Enter remarks (optional)"
            />
          </div>

          <div style={{ marginTop: "20px" }}>
            <button
              type="submit"
              style={{
                ...styles.button,
                opacity: saving ? 0.65 : 1,
              }}
              disabled={
                saving ||
                !(
                  activeTab === "PROJECT"
                    ? selectedProject
                    : selectedOfficeAllocation
                )
              }
            >
              {saving ? "Submitting..." : "Submit Expenditure"}
            </button>
          </div>
        </form>
      </div>

      <div style={styles.card}>
        <h2 style={{ fontSize: "18px", marginTop: 0, marginBottom: "16px" }}>
          Expenditure History
        </h2>

        {historyLoading ? (
          <p>Loading history...</p>
        ) : history.length === 0 ? (
          <p style={{ color: "#64748b" }}>
            No expenditure report found for this selection.
          </p>
        ) : (
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Report Date</th>
                  <th style={styles.th}>Budget Head</th>
                  <th style={styles.th}>Cumulative Amount</th>
                  <th style={styles.th}>Incremental Amount</th>
                  <th style={styles.th}>Remarks</th>
                </tr>
              </thead>
              <tbody>
                {history.map((item) => (
                  <tr key={item.id}>
                    <td style={styles.td}>{item.reportDate}</td>
                    <td style={styles.td}>
                      {headNameById.get(String(item.expenseHeadId)) || "—"}
                    </td>
                    <td style={styles.td}>
                      {money(item.cumulativeAmount)}
                    </td>
                    <td style={styles.td}>
                      {money(item.incrementalAmount)}
                    </td>
                    <td style={styles.td}>{item.remarks || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
